﻿[사용 방법]
sc create JmTunneler binPath={Path\JmTunneler.exe}
sc start JmTunneler

[삭제 방법]
sc delete JmTunneler